package org.example.task3;

import java.util.ArrayList;
import java.util.List;

public class GradeBook {
    List<Student> students;

    public GradeBook(int students, int weeks) {
        this.students = new ArrayList<>();
        for (int i = 0; i < students; i++) {
            this.students.add(new Student(weeks));
        }
    }

    public int getMark(int student, int week) {
        return this.students.get(student).getMark(week);
    }

    public void setMark(int student, int week, int mark) {
        this.students.get(student).setMark(mark, week);
    }

    public void add(int student, int week, int mark) {
        this.students.get(student).add(mark, week);
    }

    public void print(int students, int weeks, int threshold) {
        int count = 0;
        for (int i = 0; i < students; i++) {
//            for (int j = 0; j < weeks; j++) {
//                if (getMark(i, j) == 60) {
//                    System.out.printf("%d <- (%d, %d);\n", getMark(i, j), i, j);
//                    count++;
//                }
//            }
            System.out.println("i=" + i + " == " +this.students.get(i));
        }
        System.out.printf("Got %d times!%n", count);
    }
}
