package org.example.task3;


import java.util.*;

public class Main {

    private static final int GROUPS = 3;
    private static final int TEACHERS = GROUPS + 1;
    private static final int STUDENTS = 30 * GROUPS;
    private static final int WEEKS = 10;
    private static final int MARK_ASSISTANT = 60;
    private static final int MARK_LECTOR = 40;

    public static void main(String[] args) {

        GradeBook gradeBook = new GradeBook(STUDENTS, WEEKS);

        Thread[] teachers = new Thread[TEACHERS];

        putMarks(gradeBook, teachers);
        gradeBook.print(STUDENTS, WEEKS, MARK_ASSISTANT + MARK_LECTOR);
    }

    static void putMarks(GradeBook gradeBook, Thread[] teachers) {
        List<Integer> lectorMarks = new ArrayList<>();
        for (int i = 0; i < STUDENTS; i++) {
            lectorMarks.add(i);
        }

//        teachers[0] = new Thread(() -> {
//            for (int week = 0; week < WEEKS / 2; week++) {
//                for (int student = 0; student < STUDENTS; student += GROUPS) {
//                    gradeBook.add(student, week, 2);
//                }
//            }
//        }
//        );
//        teachers[0].start();
//
//        teachers[1] = new Thread(() -> {
//            for (int week = 0; week < WEEKS / 2; week++) {
//                for (int student = 1; student < STUDENTS; student += GROUPS) {
//                    gradeBook.add(student, week, 2);
//                }
//            }
//        }
//        );
//        teachers[1].start();
//
//        teachers[2] = new Thread(() -> {
//            for (int week = 0; week < WEEKS / 2; week++) {
//                for (int student = 2; student < STUDENTS; student += GROUPS) {
//                    gradeBook.add(student, week, 2);
//                }
//            }
//        }
//        );
//        teachers[2].start();
//
//        teachers[3] = new Thread(() -> {
//            for (int week = 0; week < WEEKS / 2; week++) {
//
//                Collections.shuffle(lectorMarks);
//
//                for (int student : lectorMarks) {
//                    gradeBook.add(student, week, 10);
//                }
//            }
//        }
//        );
//        teachers[3].start();

        for (int t = 0; t < TEACHERS; t++) {
            if (t < GROUPS) {
                int group = t;
                teachers[t] = new Thread(() -> {
                    for (int week = 0; week < WEEKS / 2; week++) {
                        for (int student = group; student < STUDENTS; student += GROUPS) {
                            gradeBook.add(student, week, 2);
                        }
                    }
                });
            } else {
                teachers[t] = new Thread(() -> {
                    for (int week = 0; week < WEEKS / 2; week++) {

                        Collections.shuffle(lectorMarks);

                        for (int student : lectorMarks) {
                            gradeBook.add(student, week, 10);
                        }
                    }
                });
            }
            teachers[t].start();
        }

        for (int t = 0; t < TEACHERS; t++) {
            try {
                teachers[t].join();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
