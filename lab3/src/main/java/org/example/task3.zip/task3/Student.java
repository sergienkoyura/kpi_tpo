package org.example.task3;

import java.util.*;

public class Student {
    private List<Integer> marks;

    public Student(int weeks) {
        this.marks = new ArrayList<>();
    }

    public int getMark(int week) {
        int sum = 0;
        for (int mark : marks) {
            sum += mark;
        }
        return sum;
    }

    public void add(int mark, int week){
//        marks.replace(week, mark + marks.get(week));
        marks.add(mark);
    }

    public int size() {
        return marks.size();
    }
    public void setMark(int mark, int week) {
        //marks.set(week, mark);
    }

    @Override
    public String toString() {
        return "Student{" +
                "marks=" + marks +
                '}';
    }
}
